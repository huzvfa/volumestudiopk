import Link from 'next/link'
import Image from 'next/image'

export default function Footer() {
  return (
    <footer style={{
      background: 'var(--black)',
      borderTop: '1px solid rgba(184,150,90,0.15)',
      padding: '5rem 3rem 3rem',
    }}>
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
        gap: '4rem',
        marginBottom: '4rem',
      }}>
        <div>
          <Image src="/logo_horizontal.png" alt="Volume Studio" width={160} height={53} style={{ objectFit: 'contain', height: '38px', width: 'auto', marginBottom: '1.5rem' }} />
          <p style={{ fontSize: '0.8rem', lineHeight: 1.8, color: 'var(--text-muted)', maxWidth: '260px' }}>
            We build brands that command attention. Premium social media management and Meta ads that convert.
          </p>
        </div>

        <div>
          <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.1rem', letterSpacing: '0.15em', marginBottom: '1.5rem', color: 'var(--beige)' }}>Navigation</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
            {[['/', 'Home'], ['/services', 'Services'], ['/about', 'About']].map(([href, label]) => (
              <Link key={href} href={href} style={{
                textDecoration: 'none',
                fontSize: '0.78rem',
                color: 'var(--text-muted)',
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                transition: 'color 0.3s',
              }}
              onMouseEnter={e => e.target.style.color = 'var(--gold)'}
              onMouseLeave={e => e.target.style.color = 'var(--text-muted)'}>
                {label}
              </Link>
            ))}
          </div>
        </div>

        <div>
          <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.1rem', letterSpacing: '0.15em', marginBottom: '1.5rem', color: 'var(--beige)' }}>Contact</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
            <a href="mailto:huzaifa7381@gmail.com" style={{ textDecoration: 'none', fontSize: '0.78rem', color: 'var(--text-muted)', letterSpacing: '0.05em', transition: 'color 0.3s' }}
              onMouseEnter={e => e.target.style.color = 'var(--gold)'}
              onMouseLeave={e => e.target.style.color = 'var(--text-muted)'}>
              huzaifa7381@gmail.com
            </a>
            <a href="https://instagram.com" target="_blank" rel="noopener" style={{ textDecoration: 'none', fontSize: '0.78rem', color: 'var(--text-muted)', letterSpacing: '0.05em', transition: 'color 0.3s', textTransform: 'uppercase' }}
              onMouseEnter={e => e.target.style.color = 'var(--gold)'}
              onMouseLeave={e => e.target.style.color = 'var(--text-muted)'}>
              @volumestudio
            </a>
          </div>
        </div>

        <div>
          <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.1rem', letterSpacing: '0.15em', marginBottom: '1.5rem', color: 'var(--beige)' }}>Ready to grow?</p>
          <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '1.5rem', lineHeight: 1.8 }}>
            Let's build something extraordinary together.
          </p>
          <Link href="/services#quote" style={{
            textDecoration: 'none',
            display: 'inline-block',
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '0.68rem',
            letterSpacing: '0.2em',
            textTransform: 'uppercase',
            color: 'var(--black)',
            background: 'var(--gold)',
            padding: '0.8rem 1.8rem',
          }}>
            Get a Quote
          </Link>
        </div>
      </div>

      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        paddingTop: '2rem',
        borderTop: '1px solid rgba(184,150,90,0.1)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '1rem',
      }}>
        <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', letterSpacing: '0.1em' }}>
          © 2025 Volume Studio. All rights reserved.
        </p>
        <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', letterSpacing: '0.05em' }}>
          Social Media Management · Meta Ads · Brand Growth
        </p>
      </div>
    </footer>
  )
}

'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import Image from 'next/image'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const links = [
    { href: '/', label: 'Home' },
    { href: '/services', label: 'Services' },
    { href: '/about', label: 'About' },
  ]

  return (
    <>
      <nav style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        padding: scrolled ? '1rem 3rem' : '1.8rem 3rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        background: scrolled ? 'rgba(10,10,10,0.97)' : 'transparent',
        borderBottom: scrolled ? '1px solid rgba(184,150,90,0.15)' : 'none',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        transition: 'all 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
      }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', textDecoration: 'none' }}>
          <Image src="/logo_horizontal.png" alt="Volume Studio" width={180} height={60} style={{ objectFit: 'contain', height: '42px', width: 'auto' }} />
        </Link>

        {/* Desktop links */}
        <div style={{ display: 'flex', gap: '3rem', alignItems: 'center' }} className="desktop-nav">
          {links.map(l => (
            <Link key={l.href} href={l.href} style={{
              textDecoration: 'none',
              fontFamily: 'Montserrat, sans-serif',
              fontSize: '0.72rem',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: pathname === l.href ? 'var(--gold)' : 'var(--beige)',
              position: 'relative',
              paddingBottom: '4px',
              transition: 'color 0.3s',
            }}>
              {l.label}
              {pathname === l.href && (
                <span style={{
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: '1px',
                  background: 'var(--gold)',
                }} />
              )}
            </Link>
          ))}
          <Link href="/services#quote" style={{
            textDecoration: 'none',
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '0.7rem',
            letterSpacing: '0.2em',
            textTransform: 'uppercase',
            color: 'var(--black)',
            background: 'var(--gold)',
            padding: '0.65rem 1.6rem',
            transition: 'all 0.3s',
          }}
          onMouseEnter={e => { e.target.style.background = 'var(--beige)'; }}
          onMouseLeave={e => { e.target.style.background = 'var(--gold)'; }}>
            Get a Quote
          </Link>
        </div>

        {/* Hamburger */}
        <button onClick={() => setMenuOpen(!menuOpen)} style={{
          display: 'none',
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          padding: '8px',
        }} className="hamburger" aria-label="Menu">
          <div style={{ width: '24px', height: '1px', background: 'var(--beige)', marginBottom: '7px', transition: 'all 0.3s', transform: menuOpen ? 'rotate(45deg) translate(5px,5px)' : 'none' }} />
          <div style={{ width: '24px', height: '1px', background: 'var(--beige)', marginBottom: '7px', opacity: menuOpen ? 0 : 1, transition: 'all 0.3s' }} />
          <div style={{ width: '24px', height: '1px', background: 'var(--beige)', transition: 'all 0.3s', transform: menuOpen ? 'rotate(-45deg) translate(5px,-5px)' : 'none' }} />
        </button>
      </nav>

      {/* Mobile menu */}
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'var(--black)',
        zIndex: 999,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '3rem',
        transform: menuOpen ? 'translateX(0)' : 'translateX(100%)',
        transition: 'transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)',
      }}>
        {links.map(l => (
          <Link key={l.href} href={l.href} onClick={() => setMenuOpen(false)} style={{
            textDecoration: 'none',
            fontFamily: 'Cormorant Garamond, serif',
            fontSize: '2.5rem',
            color: pathname === l.href ? 'var(--gold)' : 'var(--beige)',
            letterSpacing: '0.1em',
          }}>
            {l.label}
          </Link>
        ))}
        <Link href="/services#quote" onClick={() => setMenuOpen(false)} style={{
          textDecoration: 'none',
          fontFamily: 'Montserrat, sans-serif',
          fontSize: '0.75rem',
          letterSpacing: '0.2em',
          textTransform: 'uppercase',
          color: 'var(--black)',
          background: 'var(--gold)',
          padding: '1rem 2.5rem',
        }}>
          Get a Quote
        </Link>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .hamburger { display: block !important; }
        }
      `}</style>
    </>
  )
}

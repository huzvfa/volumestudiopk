import './globals.css'

export const metadata = {
  title: 'Volume Studio — Social Media & Meta Ads Agency',
  description: 'Premium social media management and Meta ads agency. We build brands that command attention.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  )
}

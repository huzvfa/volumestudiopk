'use client'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Cursor from '@/components/Cursor'
import Link from 'next/link'
import Image from 'next/image'
import { useEffect, useRef, useState } from 'react'

function AnimatedNumber({ target, suffix = '' }) {
  const [count, setCount] = useState(0)
  const ref = useRef(null)
  const started = useRef(false)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true
        let start = 0
        const duration = 2000
        const increment = target / (duration / 16)
        const timer = setInterval(() => {
          start += increment
          if (start >= target) {
            setCount(target)
            clearInterval(timer)
          } else {
            setCount(Math.floor(start))
          }
        }, 16)
      }
    }, { threshold: 0.5 })
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [target])

  return <span ref={ref}>{count}{suffix}</span>
}

export default function HomePage() {
  const [loaded, setLoaded] = useState(false)
  useEffect(() => { setTimeout(() => setLoaded(true), 100) }, [])

  return (
    <>
      <Cursor />
      <Navbar />

      {/* HERO */}
      <section style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        overflow: 'hidden',
        padding: '0 3rem',
      }}>
        {/* Background grid lines */}
        <div style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `
            linear-gradient(rgba(184,150,90,0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(184,150,90,0.04) 1px, transparent 1px)
          `,
          backgroundSize: '80px 80px',
          pointerEvents: 'none',
        }} />

        {/* Gradient orb */}
        <div style={{
          position: 'absolute',
          top: '20%',
          right: '-10%',
          width: '600px',
          height: '600px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(184,150,90,0.06) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute',
          bottom: '10%',
          left: '-5%',
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(232,213,183,0.04) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div style={{
          textAlign: 'center',
          maxWidth: '900px',
          opacity: loaded ? 1 : 0,
          transform: loaded ? 'translateY(0)' : 'translateY(40px)',
          transition: 'all 1.2s cubic-bezier(0.16, 1, 0.3, 1)',
        }}>
          <p style={{
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '0.7rem',
            letterSpacing: '0.4em',
            textTransform: 'uppercase',
            color: 'var(--gold)',
            marginBottom: '2rem',
          }}>
            Premium Social Media & Meta Ads Agency
          </p>

          <h1 style={{
            fontFamily: 'Cormorant Garamond, serif',
            fontSize: 'clamp(3.5rem, 8vw, 7rem)',
            fontWeight: 300,
            lineHeight: 1.0,
            color: 'var(--beige-light)',
            marginBottom: '0.3rem',
          }}>
            We Build Brands
          </h1>
          <h1 style={{
            fontFamily: 'Cormorant Garamond, serif',
            fontSize: 'clamp(3.5rem, 8vw, 7rem)',
            fontWeight: 300,
            lineHeight: 1.0,
            fontStyle: 'italic',
            color: 'var(--gold)',
            marginBottom: '2.5rem',
          }}>
            That Command Attention.
          </h1>

          <div className="divider" />

          <p style={{
            fontSize: '0.95rem',
            lineHeight: 1.9,
            color: 'var(--text-muted)',
            maxWidth: '560px',
            margin: '0 auto 3.5rem',
          }}>
            From viral Instagram content to high-converting Meta ad campaigns — Volume Studio is the agency behind brands that don't just grow, they dominate.
          </p>

          <div style={{ display: 'flex', gap: '1.5rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/services#quote" style={{
              textDecoration: 'none',
              fontFamily: 'Montserrat, sans-serif',
              fontSize: '0.72rem',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: 'var(--black)',
              background: 'var(--gold)',
              padding: '1.1rem 2.8rem',
              transition: 'all 0.3s',
              display: 'inline-block',
            }}
            onMouseEnter={e => { e.target.style.background = 'var(--beige)'; e.target.style.transform = 'translateY(-2px)'; }}
            onMouseLeave={e => { e.target.style.background = 'var(--gold)'; e.target.style.transform = 'translateY(0)'; }}>
              Get a Quote
            </Link>
            <Link href="/services" style={{
              textDecoration: 'none',
              fontFamily: 'Montserrat, sans-serif',
              fontSize: '0.72rem',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: 'var(--beige)',
              border: '1px solid rgba(232,213,183,0.3)',
              padding: '1.1rem 2.8rem',
              transition: 'all 0.3s',
              display: 'inline-block',
            }}
            onMouseEnter={e => { e.target.style.borderColor = 'var(--gold)'; e.target.style.color = 'var(--gold)'; e.target.style.transform = 'translateY(-2px)'; }}
            onMouseLeave={e => { e.target.style.borderColor = 'rgba(232,213,183,0.3)'; e.target.style.color = 'var(--beige)'; e.target.style.transform = 'translateY(0)'; }}>
              Our Services
            </Link>
          </div>
        </div>

        {/* Scroll indicator */}
        <div style={{
          position: 'absolute',
          bottom: '3rem',
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '0.5rem',
          opacity: 0.4,
        }}>
          <p style={{ fontSize: '0.6rem', letterSpacing: '0.3em', textTransform: 'uppercase', color: 'var(--beige)' }}>Scroll</p>
          <div style={{ width: '1px', height: '50px', background: 'linear-gradient(to bottom, var(--gold), transparent)' }} />
        </div>
      </section>

      {/* STATS */}
      <section style={{
        padding: '6rem 3rem',
        background: 'var(--black-2)',
        borderTop: '1px solid rgba(184,150,90,0.1)',
        borderBottom: '1px solid rgba(184,150,90,0.1)',
      }}>
        <div style={{
          maxWidth: '1100px',
          margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '3rem',
          textAlign: 'center',
        }}>
          {[
            { num: 50, suffix: '+', label: 'Brands Grown' },
            { num: 3, suffix: 'M+', label: 'Total Reach Generated' },
            { num: 98, suffix: '%', label: 'Client Retention Rate' },
            { num: 5, suffix: 'x', label: 'Average ROAS on Meta' },
          ].map(({ num, suffix, label }) => (
            <div key={label}>
              <p style={{
                fontFamily: 'Cormorant Garamond, serif',
                fontSize: 'clamp(3rem, 5vw, 4.5rem)',
                fontWeight: 300,
                color: 'var(--gold)',
                lineHeight: 1,
                marginBottom: '0.8rem',
              }}>
                <AnimatedNumber target={num} suffix={suffix} />
              </p>
              <p style={{ fontSize: '0.72rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>
                {label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES PREVIEW */}
      <section style={{ padding: '10rem 3rem' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '6rem' }}>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.2rem' }}>What We Do</p>
            <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2.5rem, 5vw, 4rem)', fontWeight: 300, color: 'var(--beige-light)' }}>
              Two Services. <em>Infinite Impact.</em>
            </h2>
            <div className="divider" />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2px' }}>
            {[
              {
                num: '01',
                title: 'Social Media Management',
                desc: 'Full-service content creation, scheduling, community management, and analytics. We become your brand voice — consistent, compelling, and built to convert.',
                items: ['Content Strategy', 'Reel & Carousel Creation', 'Daily Posting & Scheduling', 'Community Management'],
              },
              {
                num: '02',
                title: 'Boost Your Growth',
                desc: 'Meta Ads engineered for ROI. From audience targeting to creative testing, we run campaigns that bring real customers through the door.',
                items: ['Meta Ads (FB & IG)', 'Audience Research', 'A/B Creative Testing', 'Performance Reporting'],
              },
            ].map(s => (
              <div key={s.num}
                style={{
                  background: 'var(--black-2)',
                  border: '1px solid rgba(184,150,90,0.1)',
                  padding: '4rem 3rem',
                  transition: 'all 0.4s',
                  position: 'relative',
                  overflow: 'hidden',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.borderColor = 'rgba(184,150,90,0.4)'
                  e.currentTarget.style.background = 'var(--black-3)'
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.borderColor = 'rgba(184,150,90,0.1)'
                  e.currentTarget.style.background = 'var(--black-2)'
                }}
              >
                <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '4rem', color: 'rgba(184,150,90,0.12)', position: 'absolute', top: '1.5rem', right: '2rem', fontWeight: 300 }}>{s.num}</p>
                <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.3em', color: 'var(--gold)', textTransform: 'uppercase', marginBottom: '1.2rem' }}>Service {s.num}</p>
                <h3 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '2rem', fontWeight: 400, color: 'var(--beige-light)', marginBottom: '1.5rem' }}>{s.title}</h3>
                <p style={{ fontSize: '0.82rem', lineHeight: 1.9, color: 'var(--text-muted)', marginBottom: '2rem' }}>{s.desc}</p>
                <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.7rem' }}>
                  {s.items.map(item => (
                    <li key={item} style={{ display: 'flex', alignItems: 'center', gap: '0.8rem', fontSize: '0.78rem', color: 'var(--beige)', letterSpacing: '0.05em' }}>
                      <span style={{ width: '4px', height: '4px', background: 'var(--gold)', borderRadius: '50%', flexShrink: 0 }} />
                      {item}
                    </li>
                  ))}
                </ul>
                <Link href="/services#quote" style={{
                  display: 'inline-block',
                  marginTop: '2.5rem',
                  textDecoration: 'none',
                  fontFamily: 'Montserrat',
                  fontSize: '0.68rem',
                  letterSpacing: '0.2em',
                  textTransform: 'uppercase',
                  color: 'var(--gold)',
                  borderBottom: '1px solid var(--gold)',
                  paddingBottom: '3px',
                  transition: 'opacity 0.3s',
                }}>
                  Get a Quote →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY VOLUME STUDIO */}
      <section style={{ padding: '8rem 3rem', background: 'var(--black-2)', borderTop: '1px solid rgba(184,150,90,0.1)' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8rem', alignItems: 'center' }}>
          <div>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.2rem' }}>Why Us</p>
            <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2rem, 4vw, 3.5rem)', fontWeight: 300, color: 'var(--beige-light)', marginBottom: '1.5rem', lineHeight: 1.2 }}>
              Not Just an Agency.<br /><em>Your Growth Partner.</em>
            </h2>
            <div style={{ width: '40px', height: '1px', background: 'var(--gold)', marginBottom: '2rem' }} />
            <p style={{ fontSize: '0.85rem', lineHeight: 1.9, color: 'var(--text-muted)', marginBottom: '3rem' }}>
              We don't believe in vanity metrics. Every piece of content we create, every ad we run, is engineered with one goal: to grow your revenue. We've helped brands go from zero to viral, from local to global.
            </p>
            <Link href="/about" style={{
              textDecoration: 'none',
              fontFamily: 'Montserrat',
              fontSize: '0.7rem',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: 'var(--black)',
              background: 'var(--gold)',
              padding: '0.9rem 2.2rem',
              display: 'inline-block',
              transition: 'all 0.3s',
            }}
            onMouseEnter={e => { e.target.style.background = 'var(--beige)'; }}
            onMouseLeave={e => { e.target.style.background = 'var(--gold)'; }}>
              Our Story
            </Link>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
            {[
              { icon: '◈', title: 'Data-Driven', desc: 'Every decision backed by analytics and performance data.' },
              { icon: '◇', title: 'Luxury Creative', desc: 'Premium visuals that position your brand above the noise.' },
              { icon: '◉', title: 'Full-Service', desc: 'Strategy, content, ads, and reporting — all under one roof.' },
              { icon: '◎', title: 'Proven Results', desc: 'Real case studies, real numbers, real client growth.' },
            ].map(item => (
              <div key={item.title} style={{
                padding: '2rem',
                border: '1px solid rgba(184,150,90,0.12)',
                background: 'var(--black)',
                transition: 'border-color 0.3s',
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(184,150,90,0.3)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(184,150,90,0.12)'}>
                <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.5rem', color: 'var(--gold)', marginBottom: '0.8rem' }}>{item.icon}</p>
                <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.1rem', color: 'var(--beige)', marginBottom: '0.6rem' }}>{item.title}</p>
                <p style={{ fontSize: '0.75rem', lineHeight: 1.7, color: 'var(--text-muted)' }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section style={{
        padding: '10rem 3rem',
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'radial-gradient(ellipse at center, rgba(184,150,90,0.07) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.5rem' }}>
          Ready to Dominate Your Market?
        </p>
        <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2.5rem, 6vw, 5rem)', fontWeight: 300, color: 'var(--beige-light)', marginBottom: '2rem', lineHeight: 1.1 }}>
          Let's Build Something<br /><em style={{ color: 'var(--gold)' }}>Extraordinary.</em>
        </h2>
        <div className="divider" />
        <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '3rem', lineHeight: 1.8 }}>
          Join the brands that trust Volume Studio to grow their presence and revenue.
        </p>
        <Link href="/services#quote" style={{
          textDecoration: 'none',
          fontFamily: 'Montserrat',
          fontSize: '0.75rem',
          letterSpacing: '0.2em',
          textTransform: 'uppercase',
          color: 'var(--black)',
          background: 'var(--gold)',
          padding: '1.2rem 3.5rem',
          display: 'inline-block',
          transition: 'all 0.3s',
        }}
        onMouseEnter={e => { e.target.style.background = 'var(--beige)'; e.target.style.transform = 'translateY(-3px)'; }}
        onMouseLeave={e => { e.target.style.background = 'var(--gold)'; e.target.style.transform = 'translateY(0)'; }}>
          Get Your Free Quote
        </Link>
      </section>

      <Footer />

      <style>{`
        @media (max-width: 768px) {
          section { padding-left: 1.5rem !important; padding-right: 1.5rem !important; }
        }
        @media (max-width: 900px) {
          section > div[style*='grid-template-columns: 1fr 1fr'] {
            grid-template-columns: 1fr !important;
            gap: 3rem !important;
          }
        }
      `}</style>
    </>
  )
}

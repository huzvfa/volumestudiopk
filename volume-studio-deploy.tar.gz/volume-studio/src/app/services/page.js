'use client'
import { useState, useRef } from 'react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Cursor from '@/components/Cursor'
import Link from 'next/link'

function QuoteForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    service: '',
    budget: '',
    message: '',
  })
  const [status, setStatus] = useState('idle') // idle | sending | success | error

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus('sending')

    try {
      const res = await fetch('https://formsubmit.co/ajax/huzaifa7381@gmail.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          _subject: `New Quote Request from ${formData.name} — Volume Studio`,
          _template: 'table',
          name: formData.name,
          email: formData.email,
          service: formData.service,
          budget: formData.budget,
          message: formData.message,
        }),
      })
      const data = await res.json()
      if (data.success === 'true' || res.ok) {
        setStatus('success')
        setFormData({ name: '', email: '', service: '', budget: '', message: '' })
      } else {
        setStatus('error')
      }
    } catch {
      setStatus('error')
    }
  }

  const inputStyle = {
    width: '100%',
    background: 'rgba(232,213,183,0.04)',
    border: '1px solid rgba(184,150,90,0.2)',
    borderRadius: 0,
    padding: '1rem 1.2rem',
    color: 'var(--beige)',
    fontFamily: 'Montserrat, sans-serif',
    fontSize: '0.82rem',
    letterSpacing: '0.03em',
    outline: 'none',
    transition: 'border-color 0.3s',
    WebkitAppearance: 'none',
  }

  const labelStyle = {
    display: 'block',
    fontFamily: 'Montserrat, sans-serif',
    fontSize: '0.65rem',
    letterSpacing: '0.2em',
    textTransform: 'uppercase',
    color: 'var(--gold)',
    marginBottom: '0.5rem',
  }

  if (status === 'success') {
    return (
      <div style={{
        padding: '5rem 3rem',
        textAlign: 'center',
        border: '1px solid rgba(184,150,90,0.2)',
        background: 'var(--black-2)',
      }}>
        <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '3rem', color: 'var(--gold)', marginBottom: '1rem' }}>✦</p>
        <h3 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '2rem', color: 'var(--beige-light)', marginBottom: '1rem' }}>
          Quote Received
        </h3>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.9 }}>
          Thank you for reaching out. We'll be in touch within 24 hours to discuss how Volume Studio can transform your brand.
        </p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.8rem' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
        <div>
          <label style={labelStyle}>Your Name</label>
          <input
            type="text"
            name="name"
            required
            placeholder="John Smith"
            value={formData.name}
            onChange={handleChange}
            style={inputStyle}
            onFocus={e => e.target.style.borderColor = 'rgba(184,150,90,0.6)'}
            onBlur={e => e.target.style.borderColor = 'rgba(184,150,90,0.2)'}
          />
        </div>
        <div>
          <label style={labelStyle}>Your Email</label>
          <input
            type="email"
            name="email"
            required
            placeholder="john@company.com"
            value={formData.email}
            onChange={handleChange}
            style={inputStyle}
            onFocus={e => e.target.style.borderColor = 'rgba(184,150,90,0.6)'}
            onBlur={e => e.target.style.borderColor = 'rgba(184,150,90,0.2)'}
          />
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
        <div>
          <label style={labelStyle}>Service Needed</label>
          <select
            name="service"
            required
            value={formData.service}
            onChange={handleChange}
            style={{ ...inputStyle, cursor: 'pointer' }}
            onFocus={e => e.target.style.borderColor = 'rgba(184,150,90,0.6)'}
            onBlur={e => e.target.style.borderColor = 'rgba(184,150,90,0.2)'}
          >
            <option value="" style={{ background: '#111' }}>Select a Service</option>
            <option value="Social Media Management" style={{ background: '#111' }}>Social Media Management</option>
            <option value="Boost Your Growth (Meta Ads)" style={{ background: '#111' }}>Boost Your Growth (Meta Ads)</option>
            <option value="Both Services" style={{ background: '#111' }}>Both Services</option>
          </select>
        </div>
        <div>
          <label style={labelStyle}>Monthly Budget</label>
          <select
            name="budget"
            value={formData.budget}
            onChange={handleChange}
            style={{ ...inputStyle, cursor: 'pointer' }}
            onFocus={e => e.target.style.borderColor = 'rgba(184,150,90,0.6)'}
            onBlur={e => e.target.style.borderColor = 'rgba(184,150,90,0.2)'}
          >
            <option value="" style={{ background: '#111' }}>Select Budget Range</option>
            <option value="Under $500" style={{ background: '#111' }}>Under $500</option>
            <option value="$500 - $1,500" style={{ background: '#111' }}>$500 – $1,500</option>
            <option value="$1,500 - $5,000" style={{ background: '#111' }}>$1,500 – $5,000</option>
            <option value="$5,000+" style={{ background: '#111' }}>$5,000+</option>
          </select>
        </div>
      </div>

      <div>
        <label style={labelStyle}>Tell Us About Your Brand</label>
        <textarea
          name="message"
          required
          rows={5}
          placeholder="Share your goals, current challenges, and what you're looking to achieve..."
          value={formData.message}
          onChange={handleChange}
          style={{ ...inputStyle, resize: 'vertical', lineHeight: 1.7 }}
          onFocus={e => e.target.style.borderColor = 'rgba(184,150,90,0.6)'}
          onBlur={e => e.target.style.borderColor = 'rgba(184,150,90,0.2)'}
        />
      </div>

      {status === 'error' && (
        <p style={{ fontSize: '0.78rem', color: '#e07070', letterSpacing: '0.05em' }}>
          Something went wrong. Please email us directly at huzaifa7381@gmail.com
        </p>
      )}

      <button
        type="submit"
        disabled={status === 'sending'}
        style={{
          fontFamily: 'Montserrat, sans-serif',
          fontSize: '0.72rem',
          letterSpacing: '0.2em',
          textTransform: 'uppercase',
          color: 'var(--black)',
          background: status === 'sending' ? 'var(--beige-dark)' : 'var(--gold)',
          border: 'none',
          padding: '1.2rem 3rem',
          cursor: 'pointer',
          transition: 'all 0.3s',
          alignSelf: 'flex-start',
        }}
        onMouseEnter={e => { if (status !== 'sending') e.target.style.background = 'var(--beige)' }}
        onMouseLeave={e => { if (status !== 'sending') e.target.style.background = 'var(--gold)' }}
      >
        {status === 'sending' ? 'Sending...' : 'Submit Quote Request →'}
      </button>
    </form>
  )
}

// Portfolio card
function PortfolioCard({ brand, handle, result, desc, tag }) {
  return (
    <div style={{
      border: '1px solid rgba(184,150,90,0.15)',
      background: 'var(--black-2)',
      padding: '3rem',
      transition: 'all 0.4s',
      position: 'relative',
    }}
    onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(184,150,90,0.4)'; e.currentTarget.style.transform = 'translateY(-4px)'; }}
    onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(184,150,90,0.15)'; e.currentTarget.style.transform = 'translateY(0)'; }}>
      <div style={{
        position: 'absolute',
        top: '1.5rem',
        right: '1.5rem',
        background: 'rgba(184,150,90,0.1)',
        border: '1px solid rgba(184,150,90,0.2)',
        padding: '0.3rem 0.8rem',
        fontSize: '0.6rem',
        letterSpacing: '0.15em',
        textTransform: 'uppercase',
        color: 'var(--gold)',
      }}>
        {tag}
      </div>
      <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.8rem', color: 'var(--beige-light)', fontWeight: 400, marginBottom: '0.3rem' }}>{brand}</p>
      <p style={{ fontSize: '0.68rem', color: 'var(--gold)', letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: '1.5rem' }}>{handle}</p>
      <div style={{ width: '30px', height: '1px', background: 'var(--gold)', marginBottom: '1.5rem' }} />
      <p style={{ fontSize: '0.82rem', lineHeight: 1.8, color: 'var(--text-muted)', marginBottom: '2rem' }}>{desc}</p>
      <div style={{ borderTop: '1px solid rgba(184,150,90,0.1)', paddingTop: '1.5rem' }}>
        <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.6rem', color: 'var(--gold)' }}>{result}</p>
        <p style={{ fontSize: '0.65rem', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--text-muted)', marginTop: '0.3rem' }}>Key Result</p>
      </div>
    </div>
  )
}

export default function ServicesPage() {
  return (
    <>
      <Cursor />
      <Navbar />

      {/* PAGE HERO */}
      <section style={{
        paddingTop: '14rem',
        paddingBottom: '8rem',
        paddingLeft: '3rem',
        paddingRight: '3rem',
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `linear-gradient(rgba(184,150,90,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(184,150,90,0.03) 1px, transparent 1px)`,
          backgroundSize: '80px 80px',
        }} />
        <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.2rem', position: 'relative' }}>Our Offerings</p>
        <h1 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(3rem, 7vw, 6rem)', fontWeight: 300, color: 'var(--beige-light)', lineHeight: 1.0, position: 'relative' }}>
          Services Built<br /><em style={{ color: 'var(--gold)' }}>For Growth.</em>
        </h1>
        <div className="divider" />
        <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', lineHeight: 1.9, maxWidth: '500px', margin: '0 auto', position: 'relative' }}>
          Two precision-engineered services designed to take your brand from invisible to undeniable.
        </p>
      </section>

      {/* SERVICE 01 */}
      <section style={{ padding: '8rem 3rem', background: 'var(--black-2)', borderTop: '1px solid rgba(184,150,90,0.08)' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8rem', alignItems: 'start' }}>
          <div>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.6rem', letterSpacing: '0.35em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1rem' }}>Service 01</p>
            <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2rem, 4vw, 3.2rem)', fontWeight: 300, color: 'var(--beige-light)', lineHeight: 1.15, marginBottom: '1.5rem' }}>
              Social Media<br />Management
            </h2>
            <div style={{ width: '40px', height: '1px', background: 'var(--gold)', marginBottom: '2rem' }} />
            <p style={{ fontSize: '0.85rem', lineHeight: 1.95, color: 'var(--text-muted)', marginBottom: '1.5rem' }}>
              We take complete ownership of your social media presence. From strategy to execution — your brand will have a voice that stops the scroll and converts followers into loyal customers.
            </p>
            <p style={{ fontSize: '0.85rem', lineHeight: 1.95, color: 'var(--text-muted)' }}>
              Our team creates platform-native content engineered for the algorithm while remaining unmistakably on-brand. We handle Instagram, Facebook, TikTok, and beyond.
            </p>
          </div>
          <div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1px' }}>
              {[
                { title: 'Brand Strategy & Positioning', desc: 'Define your voice, aesthetic, and content pillars from the ground up.' },
                { title: 'Content Creation (Reels, Carousels, Stories)', desc: 'High-quality visuals and copy engineered for reach and engagement.' },
                { title: 'Content Calendar & Scheduling', desc: 'Consistent daily posting at peak times for maximum visibility.' },
                { title: 'Community Management', desc: 'Real-time responses, DM management, and audience relationship building.' },
                { title: 'Monthly Analytics & Reporting', desc: 'Clear performance data with actionable insights and adjustments.' },
                { title: 'Hashtag & SEO Optimization', desc: 'Strategic discoverability to expand reach organically every month.' },
              ].map(item => (
                <div key={item.title} style={{
                  padding: '1.5rem 2rem',
                  background: 'var(--black)',
                  borderLeft: '2px solid transparent',
                  transition: 'all 0.3s',
                }}
                onMouseEnter={e => { e.currentTarget.style.borderLeftColor = 'var(--gold)'; e.currentTarget.style.paddingLeft = '2.5rem'; }}
                onMouseLeave={e => { e.currentTarget.style.borderLeftColor = 'transparent'; e.currentTarget.style.paddingLeft = '2rem'; }}>
                  <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.05rem', color: 'var(--beige)', marginBottom: '0.3rem' }}>{item.title}</p>
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SERVICE 02 */}
      <section style={{ padding: '8rem 3rem' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8rem', alignItems: 'start' }}>
          <div style={{ order: 2 }}>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.6rem', letterSpacing: '0.35em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1rem' }}>Service 02</p>
            <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2rem, 4vw, 3.2rem)', fontWeight: 300, color: 'var(--beige-light)', lineHeight: 1.15, marginBottom: '1.5rem' }}>
              Boost Your<br />Growth
            </h2>
            <div style={{ width: '40px', height: '1px', background: 'var(--gold)', marginBottom: '2rem' }} />
            <p style={{ fontSize: '0.85rem', lineHeight: 1.95, color: 'var(--text-muted)', marginBottom: '1.5rem' }}>
              Meta Ads are the fastest way to scale — when they're done right. We build and manage Facebook and Instagram advertising campaigns that are laser-targeted, beautifully designed, and ruthlessly optimised for ROI.
            </p>
            <p style={{ fontSize: '0.85rem', lineHeight: 1.95, color: 'var(--text-muted)' }}>
              Whether you want more sales, more bookings, or more brand awareness, we architect campaigns that deliver. No wasted spend. No guesswork.
            </p>
          </div>
          <div style={{ order: 1 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1px' }}>
              {[
                { title: 'Meta Ads Strategy & Setup', desc: 'Full campaign architecture across Facebook & Instagram Ads Manager.' },
                { title: 'Audience Research & Targeting', desc: 'Laser-precise custom and lookalike audiences built from your data.' },
                { title: 'Ad Creative Design & Copywriting', desc: 'Scroll-stopping ads that communicate your value instantly.' },
                { title: 'A/B Testing Framework', desc: 'Systematic creative and audience testing to find winning combinations.' },
                { title: 'Retargeting Campaigns', desc: 'Re-engage warm audiences and cart abandoners to maximise conversions.' },
                { title: 'Weekly Performance Reporting', desc: "Transparent ROAS and KPI dashboards so you always know what's working." },
              ].map(item => (
                <div key={item.title} style={{
                  padding: '1.5rem 2rem',
                  background: 'var(--black-2)',
                  borderLeft: '2px solid transparent',
                  transition: 'all 0.3s',
                }}
                onMouseEnter={e => { e.currentTarget.style.borderLeftColor = 'var(--gold)'; e.currentTarget.style.paddingLeft = '2.5rem'; }}
                onMouseLeave={e => { e.currentTarget.style.borderLeftColor = 'transparent'; e.currentTarget.style.paddingLeft = '2rem'; }}>
                  <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.05rem', color: 'var(--beige)', marginBottom: '0.3rem' }}>{item.title}</p>
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* PORTFOLIO */}
      <section style={{ padding: '8rem 3rem', background: 'var(--black-2)', borderTop: '1px solid rgba(184,150,90,0.08)' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '5rem' }}>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.2rem' }}>Client Portfolio</p>
            <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2rem, 4vw, 3.5rem)', fontWeight: 300, color: 'var(--beige-light)' }}>
              Brands We've <em>Transformed</em>
            </h2>
            <div className="divider" />
            <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', maxWidth: '500px', margin: '0 auto', lineHeight: 1.9 }}>
              Real clients. Real results. Here's what happens when premium strategy meets flawless execution.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem' }}>
            <PortfolioCard
              brand="Monark Rentals"
              handle="@monarkrentals"
              tag="Social Media"
              result="+340% Organic Reach"
              desc="Monark Rentals came to Volume Studio with minimal Instagram presence and low booking rates. We built a cohesive luxury aesthetic, introduced cinematic Reels content, and grew their organic reach by 340% in just 90 days — translating directly into a 60% increase in direct bookings."
            />
            <PortfolioCard
              brand="NPC Threads"
              handle="@npcthreads"
              tag="Meta Ads + Social"
              result="5.2x ROAS Achieved"
              desc="NPC Threads, an emerging streetwear brand, needed Meta Ads that matched their edgy identity. Volume Studio built a full-funnel campaign with custom creatives and precision targeting. The result: 5.2x return on ad spend and a sold-out collection within 3 weeks of launch."
            />
          </div>

          {/* Testimonials */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem', marginTop: '1.5rem' }}>
            {[
              {
                quote: "Volume Studio completely changed how people perceive our rental brand. The content quality is on another level. Our bookings have never been higher.",
                author: "— Monark Rentals",
                role: "Luxury Vacation Rentals",
              },
              {
                quote: "We were burning money on ads before Volume Studio. They rebuilt everything from scratch and delivered results we didn't think were possible for our budget.",
                author: "— NPC Threads",
                role: "Streetwear Brand",
              },
            ].map(t => (
              <div key={t.author} style={{
                padding: '3rem',
                border: '1px solid rgba(184,150,90,0.12)',
                background: 'var(--black)',
                position: 'relative',
              }}>
                <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '3rem', color: 'var(--gold)', lineHeight: 0.5, marginBottom: '1.5rem', opacity: 0.4 }}>"</p>
                <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.15rem', lineHeight: 1.8, color: 'var(--beige-light)', fontStyle: 'italic', marginBottom: '2rem' }}>
                  {t.quote}
                </p>
                <p style={{ fontSize: '0.75rem', letterSpacing: '0.1em', color: 'var(--gold)', marginBottom: '0.3rem' }}>{t.author}</p>
                <p style={{ fontSize: '0.65rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>{t.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* QUOTE FORM */}
      <section id="quote" style={{ padding: '10rem 3rem' }}>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '5rem' }}>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.2rem' }}>Work With Us</p>
            <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2rem, 4vw, 3.5rem)', fontWeight: 300, color: 'var(--beige-light)', marginBottom: '1rem' }}>
              Get a <em>Free Quote</em>
            </h2>
            <div className="divider" />
            <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.9 }}>
              Tell us about your brand and goals. We'll get back to you within 24 hours with a custom proposal.
            </p>
          </div>
          <QuoteForm />
        </div>
      </section>

      <Footer />

      <style>{`
        @media (max-width: 900px) {
          section > div[style*='grid-template-columns: 1fr 1fr'] {
            grid-template-columns: 1fr !important;
            gap: 3rem !important;
          }
          div[style*='grid-template-columns: 1fr 1fr'][style*='gap: 1.5rem'] {
            grid-template-columns: 1fr !important;
          }
        }
        @media (max-width: 768px) {
          section { padding-left: 1.5rem !important; padding-right: 1.5rem !important; }
        }
      `}</style>
    </>
  )
}

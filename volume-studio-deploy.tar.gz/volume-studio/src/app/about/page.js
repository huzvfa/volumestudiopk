'use client'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Cursor from '@/components/Cursor'
import Link from 'next/link'
import Image from 'next/image'

function PortfolioDeepDive({ brand, handle, tag, challenge, solution, results, quote, quoteAuthor }) {
  return (
    <div style={{
      border: '1px solid rgba(184,150,90,0.15)',
      background: 'var(--black-2)',
      overflow: 'hidden',
      transition: 'border-color 0.4s',
    }}
    onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(184,150,90,0.35)'}
    onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(184,150,90,0.15)'}>
      <div style={{
        background: 'linear-gradient(135deg, rgba(184,150,90,0.08), transparent)',
        padding: '3rem',
        borderBottom: '1px solid rgba(184,150,90,0.1)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        gap: '1rem',
      }}>
        <div>
          <span style={{
            display: 'inline-block',
            background: 'rgba(184,150,90,0.12)',
            border: '1px solid rgba(184,150,90,0.25)',
            padding: '0.3rem 0.9rem',
            fontSize: '0.6rem',
            letterSpacing: '0.2em',
            textTransform: 'uppercase',
            color: 'var(--gold)',
            marginBottom: '1rem',
          }}>{tag}</span>
          <h3 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '2.2rem', color: 'var(--beige-light)', fontWeight: 400, marginBottom: '0.3rem' }}>{brand}</h3>
          <p style={{ fontSize: '0.7rem', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)' }}>{handle}</p>
        </div>
        <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap' }}>
          {results.map(r => (
            <div key={r.label} style={{ textAlign: 'right' }}>
              <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '2rem', color: 'var(--gold)', fontWeight: 300 }}>{r.value}</p>
              <p style={{ fontSize: '0.6rem', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>{r.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '3rem', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3rem' }}>
        <div>
          <p style={{ fontFamily: 'Montserrat', fontSize: '0.6rem', letterSpacing: '0.3em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '0.8rem' }}>The Challenge</p>
          <p style={{ fontSize: '0.82rem', lineHeight: 1.9, color: 'var(--text-muted)' }}>{challenge}</p>
        </div>
        <div>
          <p style={{ fontFamily: 'Montserrat', fontSize: '0.6rem', letterSpacing: '0.3em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '0.8rem' }}>Our Solution</p>
          <p style={{ fontSize: '0.82rem', lineHeight: 1.9, color: 'var(--text-muted)' }}>{solution}</p>
        </div>
      </div>

      <div style={{
        margin: '0 3rem 3rem',
        padding: '2.5rem',
        borderLeft: '3px solid var(--gold)',
        background: 'rgba(184,150,90,0.04)',
      }}>
        <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.2rem', fontStyle: 'italic', color: 'var(--beige-light)', lineHeight: 1.7, marginBottom: '1rem' }}>
          "{quote}"
        </p>
        <p style={{ fontSize: '0.7rem', letterSpacing: '0.15em', color: 'var(--gold)', textTransform: 'uppercase' }}>{quoteAuthor}</p>
      </div>
    </div>
  )
}

export default function AboutPage() {
  return (
    <>
      <Cursor />
      <Navbar />

      {/* HERO */}
      <section style={{
        paddingTop: '16rem',
        paddingBottom: '10rem',
        paddingLeft: '3rem',
        paddingRight: '3rem',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `linear-gradient(rgba(184,150,90,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(184,150,90,0.03) 1px, transparent 1px)`,
          backgroundSize: '80px 80px',
        }} />

        <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8rem', alignItems: 'center' }}>
          <div>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.2rem', position: 'relative' }}>Our Story</p>
            <h1 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2.5rem, 5vw, 5rem)', fontWeight: 300, color: 'var(--beige-light)', lineHeight: 1.05, marginBottom: '2rem', position: 'relative' }}>
              Built for Brands<br /><em style={{ color: 'var(--gold)' }}>That Refuse to be<br />Invisible.</em>
            </h1>
            <div style={{ width: '40px', height: '1px', background: 'var(--gold)', marginBottom: '2rem' }} />
            <p style={{ fontSize: '0.88rem', lineHeight: 1.95, color: 'var(--text-muted)', position: 'relative' }}>
              Volume Studio was founded on one belief: that every brand deserves world-class social media — not just the ones with million-dollar budgets. We've built a boutique, results-obsessed agency that treats every client like they're our only one.
            </p>
          </div>

          <div style={{ position: 'relative' }}>
            <div style={{
              border: '1px solid rgba(184,150,90,0.2)',
              padding: '4rem 3rem',
              background: 'var(--black-2)',
              position: 'relative',
            }}>
              <div style={{ position: 'absolute', top: '-1px', left: '2rem', right: '2rem', height: '2px', background: 'linear-gradient(90deg, transparent, var(--gold), transparent)' }} />
              <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '3.5rem', fontStyle: 'italic', color: 'rgba(184,150,90,0.15)', lineHeight: 0.8, marginBottom: '1rem' }}>"</p>
              <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.4rem', fontStyle: 'italic', lineHeight: 1.6, color: 'var(--beige-light)', marginBottom: '2rem' }}>
                We don't post content. We engineer moments that make people stop, feel something, and act.
              </p>
              <p style={{ fontSize: '0.7rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--gold)' }}>— Volume Studio Founding Principle</p>
            </div>
          </div>
        </div>
      </section>

      {/* VALUES */}
      <section style={{ padding: '8rem 3rem', background: 'var(--black-2)', borderTop: '1px solid rgba(184,150,90,0.08)' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '5rem' }}>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.2rem' }}>What We Stand For</p>
            <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2rem, 4vw, 3.5rem)', fontWeight: 300, color: 'var(--beige-light)' }}>
              Our <em>Core Values</em>
            </h2>
            <div className="divider" />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1px' }}>
            {[
              { num: '01', title: 'Results, Not Excuses', desc: 'We measure success by what actually happens — revenue, bookings, sales. Vanity metrics don\'t pay bills.' },
              { num: '02', title: 'Premium Everything', desc: 'From the first strategy call to the final report — every touchpoint is crafted to the highest standard.' },
              { num: '03', title: 'Transparency First', desc: 'No smoke and mirrors. You see every number, every campaign, every result. Always.' },
              { num: '04', title: 'Growth Obsession', desc: 'We\'re never satisfied with last month\'s results. We\'re always testing, learning, and pushing higher.' },
            ].map(v => (
              <div key={v.num} style={{
                padding: '3rem 2.5rem',
                background: 'var(--black)',
                borderBottom: '2px solid transparent',
                transition: 'all 0.3s',
              }}
              onMouseEnter={e => { e.currentTarget.style.borderBottomColor = 'var(--gold)'; e.currentTarget.style.background = 'var(--black-3)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderBottomColor = 'transparent'; e.currentTarget.style.background = 'var(--black)'; }}>
                <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '3rem', color: 'rgba(184,150,90,0.15)', fontWeight: 300, lineHeight: 1, marginBottom: '1.5rem' }}>{v.num}</p>
                <h3 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1.4rem', color: 'var(--beige)', marginBottom: '1rem' }}>{v.title}</h3>
                <p style={{ fontSize: '0.78rem', lineHeight: 1.8, color: 'var(--text-muted)' }}>{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHAT MAKES US DIFFERENT */}
      <section style={{ padding: '8rem 3rem' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8rem', alignItems: 'center' }}>
          <div>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.2rem' }}>The Volume Difference</p>
            <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2rem, 4vw, 3.2rem)', fontWeight: 300, color: 'var(--beige-light)', marginBottom: '2rem', lineHeight: 1.2 }}>
              Small Enough to Care.<br /><em>Strategic Enough to Win.</em>
            </h2>
            <div style={{ width: '40px', height: '1px', background: 'var(--gold)', marginBottom: '2rem' }} />
            <p style={{ fontSize: '0.85rem', lineHeight: 1.95, color: 'var(--text-muted)', marginBottom: '1.5rem' }}>
              Unlike bloated agencies with 200 clients and junior account managers, Volume Studio is selective. We take on fewer clients so we can deliver more impact for each one.
            </p>
            <p style={{ fontSize: '0.85rem', lineHeight: 1.95, color: 'var(--text-muted)', marginBottom: '3rem' }}>
              When you work with us, you get the founder's attention. You get strategy, not templates. You get results, not reports.
            </p>
            <Link href="/services#quote" style={{
              textDecoration: 'none',
              fontFamily: 'Montserrat',
              fontSize: '0.7rem',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: 'var(--black)',
              background: 'var(--gold)',
              padding: '0.9rem 2.2rem',
              display: 'inline-block',
              transition: 'all 0.3s',
            }}
            onMouseEnter={e => e.target.style.background = 'var(--beige)'}
            onMouseLeave={e => e.target.style.background = 'var(--gold)'}>
              Start the Conversation
            </Link>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {[
              { label: 'Boutique & Selective', val: 'Max 20 clients at a time for full attention' },
              { label: 'Founder-Led Strategy', val: 'Senior creative & strategy on every account' },
              { label: 'Platform-Native Content', val: 'Built for how algorithms actually work today' },
              { label: 'No Lock-In Contracts', val: 'Month-to-month — we earn your trust every month' },
            ].map(item => (
              <div key={item.label} style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '1.5rem 2rem',
                border: '1px solid rgba(184,150,90,0.12)',
                background: 'var(--black-2)',
                gap: '2rem',
                transition: 'border-color 0.3s',
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(184,150,90,0.3)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(184,150,90,0.12)'}>
                <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '1rem', color: 'var(--beige)' }}>{item.label}</p>
                <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textAlign: 'right', maxWidth: '200px', lineHeight: 1.5 }}>{item.val}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PORTFOLIO DEEP DIVES */}
      <section style={{ padding: '8rem 3rem', background: 'var(--black-2)', borderTop: '1px solid rgba(184,150,90,0.08)' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '5rem' }}>
            <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.2rem' }}>Portfolio</p>
            <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2rem, 4vw, 3.5rem)', fontWeight: 300, color: 'var(--beige-light)' }}>
              Case <em>Studies</em>
            </h2>
            <div className="divider" />
            <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', maxWidth: '480px', margin: '0 auto', lineHeight: 1.9 }}>
              Deep dives into how we transformed these brands with strategy, creativity, and execution.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <PortfolioDeepDive
              brand="Monark Rentals"
              handle="@monarkrentals"
              tag="Social Media Management"
              challenge="Monark Rentals had an Instagram account with inconsistent posting, low-quality visuals, and engagement sitting below 1%. Direct bookings through social were nearly zero. Competitors were outpacing them despite Monark having a superior property."
              solution="We audited their entire digital presence and repositioned the brand as a luxury lifestyle destination rather than just a rental. We introduced a signature cinematic Reel style, implemented a structured content calendar with 6 posts per week, and launched a community engagement strategy that turned followers into advocates."
              results={[
                { value: '+340%', label: 'Organic Reach' },
                { value: '+60%', label: 'Direct Bookings' },
                { value: '4.8%', label: 'Engagement Rate' },
              ]}
              quote="Volume Studio didn't just manage our Instagram — they transformed how people see our brand. The quality of their content is unreal, and our bookings have never been higher. Worth every penny."
              quoteAuthor="— Monark Rentals Management Team"
            />

            <PortfolioDeepDive
              brand="NPC Threads"
              handle="@npcthreads"
              tag="Meta Ads + Social Media"
              challenge="NPC Threads, a bold streetwear label, had a strong offline following but struggled to translate that to online revenue. Their Meta Ads were running without strategy — broad targeting, generic creatives, and a ROAS hovering around 0.8x. Money was being lost every day."
              solution="Volume Studio tore down their entire ads account and rebuilt it from the ground up. We created a full-funnel campaign: cold audience prospecting with raw, authentic UGC-style creatives, a warm retargeting layer targeting video viewers and site visitors, and a cart abandonment recovery sequence. Every creative was A/B tested weekly."
              results={[
                { value: '5.2x', label: 'ROAS' },
                { value: 'Sold Out', label: 'In 3 Weeks' },
                { value: '-74%', label: 'Cost per Purchase' },
              ]}
              quote="Before Volume Studio, we were losing money on every campaign. They came in, changed literally everything, and now we can't keep stock on the shelves. The results speak for themselves."
              quoteAuthor="— NPC Threads Founder"
            />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{
        padding: '10rem 3rem',
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, rgba(184,150,90,0.06) 0%, transparent 70%)', pointerEvents: 'none' }} />
        <p style={{ fontFamily: 'Montserrat', fontSize: '0.65rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.5rem', position: 'relative' }}>
          Your Brand Could Be Next
        </p>
        <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(2.5rem, 6vw, 5rem)', fontWeight: 300, color: 'var(--beige-light)', marginBottom: '2rem', lineHeight: 1.1, position: 'relative' }}>
          Ready to Write<br /><em style={{ color: 'var(--gold)' }}>Your Success Story?</em>
        </h2>
        <div className="divider" />
        <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '3rem', lineHeight: 1.8, position: 'relative' }}>
          Join Monark Rentals, NPC Threads, and more brands that trusted Volume Studio with their growth.
        </p>
        <Link href="/services#quote" style={{
          textDecoration: 'none',
          fontFamily: 'Montserrat',
          fontSize: '0.75rem',
          letterSpacing: '0.2em',
          textTransform: 'uppercase',
          color: 'var(--black)',
          background: 'var(--gold)',
          padding: '1.2rem 3.5rem',
          display: 'inline-block',
          transition: 'all 0.3s',
          position: 'relative',
        }}
        onMouseEnter={e => { e.target.style.background = 'var(--beige)'; e.target.style.transform = 'translateY(-3px)'; }}
        onMouseLeave={e => { e.target.style.background = 'var(--gold)'; e.target.style.transform = 'translateY(0)'; }}>
          Get Your Free Quote
        </Link>
      </section>

      <Footer />

      <style>{`
        @media (max-width: 900px) {
          section > div[style*='grid-template-columns: 1fr 1fr'] {
            grid-template-columns: 1fr !important;
            gap: 3rem !important;
          }
          div[style*='grid-template-columns: 1fr 1fr'][style*='gap: 3rem'] {
            grid-template-columns: 1fr !important;
          }
        }
        @media (max-width: 768px) {
          section { padding-left: 1.5rem !important; padding-right: 1.5rem !important; }
        }
      `}</style>
    </>
  )
}
